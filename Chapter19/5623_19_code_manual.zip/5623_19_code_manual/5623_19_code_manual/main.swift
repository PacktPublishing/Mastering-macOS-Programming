

import Foundation


let json = JSON(["hello", "manual", "installation"])

for str in json
{
  print(str.1)
}
