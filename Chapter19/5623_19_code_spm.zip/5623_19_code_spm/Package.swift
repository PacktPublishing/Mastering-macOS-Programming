import PackageDescription

let package = Package(
    name: "5623_19_code_spm",
    dependencies: [
        .Package(url: "https://github.com/SwiftyJSON/SwiftyJSON.git", majorVersion: 3, minor: 1)
    ]
)

