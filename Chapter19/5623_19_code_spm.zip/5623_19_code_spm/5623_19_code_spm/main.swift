

import Foundation
import SwiftyJSON

let json = JSON(["hello", "swift", "project", "manager"])
for str in json
{
  print(str.1)
}


